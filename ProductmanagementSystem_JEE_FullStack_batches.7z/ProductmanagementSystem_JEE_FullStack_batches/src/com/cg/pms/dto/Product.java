package com.cg.pms.dto;

public class Product {

	private Integer productId;
	private String productName;
	private Double productCost;
	private Integer quantity;

	public Product(String productName, Double productCost, Integer quantity) {
		super();
		this.productName = productName;
		this.productCost = productCost;
		this.quantity = quantity;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(Integer productId, String productName, Double productCost, Integer quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCost = productCost;
		this.quantity = quantity;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductCost() {
		return productCost;
	}

	public void setProductCost(Double productCost) {
		this.productCost = productCost;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productCost=" + productCost
				+ ", quantity=" + quantity + "]";
	}

}
