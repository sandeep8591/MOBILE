package com.cg.bank.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class CollectionUtil {
 private static HashMap<Long,Customer> map1= new HashMap<Long,Customer>();
 static
 {
	 map1.put(9031278363l, new Customer("GOVRAV", "8951509664", 25,903127836l));
	 map1.put(9031278363l,new Customer("ARUN", "8632633451", 21,987276353l));
	 map1.put(9032186632l,new Customer("JENNIFER", "86326374381", 16,903218663l) );
	 map1.put(9023948731l, new Customer("RUHANN", "7642962492L", 56,902394873l));
 }
	private static HashMap<Long,Account> map2=new HashMap<>();
	
	static
	{
		map2.put(9031278363l, new Account(352753, 9031278363l, LocalDate.of(2017,Month.APRIL, 12)));
		map2.put(9872763531l, new Account(312412, 9872763531l, LocalDate.of(2013,Month.MAY, 19) ));
		map2.put(9032186632l,new Account(546678,9032186632l ,LocalDate.of(2013,Month.MAY, 19 )));
		
	}
	
	public static void addCustmrDetails(long accno,Customer cus)
	{
		map1.put(accno,cus);
	}
	public static void addAccDetails(long accno,Account acc)
	{
		map2.put(accno, acc);
	}
	public static Account withDraw( long accNo,double bal)
	{
		
		return map2.get(accNo);
		
	}
	public static Account deposit(long accNo,double bal)
	{
		return map2.get(accNo);
	}
	public static Account fundTransferDetails(long accNo)
	{
		return map2.get(accNo);
		
	}
	public static Account showBalance(long accNo)
	{
		return map2.get(accNo);
		
	}
	public static HashMap<Long,Account> fetchAccount(){
		return map2;
	}
}
