package com.cg.bank.ui;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankService;
import com.cg.bank.service.BankServiceImpl;

public class RunMain {
static Scanner sc=null;
static BankService bankService=null;
public static void main(String[] args) {
	sc=new Scanner(System.in);
	bankService=new BankServiceImpl();
	System.out.println("WELCOME TO XYZ BANK");
	System.out.println("1.TO CREATE ACCOUNT");
	System.out.println("2. TO SHOW BALANCE");
	System.out.println("3. TO DEPOSIT");
	System.out.println("4.TO WITHdRAW");
	System.out.println("5. TO FUND TRANSFER");
	
	System.out.println("ENTER THE CHOICE");
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1: createAccount();
	        break;
	case 2: showBalance();
	        break;
	case 3:  toDeposit();
	        break;
	case 4:  toWithDraw();
	        break;
	case 5:  toFundTransfer();
	        break;
	
	default: System.exit(0);
	
	
	}
}
public static void createAccount()
{
	System.out.println("ENTER THE CUSTOMER DETAILS");
	System.out.println("ENTER NAME");
	String cusName=sc.next();
	try
	{
	if(bankService.validateName(cusName)==true)
	{
		System.out.println("ENTER PHONENO");
		long phoneNo1=sc.nextLong();
		String phoneNo=String.valueOf(phoneNo1);
	
		try
		{
			if(bankService.validateCellNo(phoneNo)==true)
			{
				System.out.println("ENTER AGE");
				int age1=sc.nextInt();
				String age=String.valueOf(age1);
				try
				{
					if(bankService.validateAge(age)==true)
					{
						
						System.out.println("MINIMUM BALANCE SHOULD BE MAINTAINED TO CREATE ACCOUNT");
						System.out.println("ENTER THE AMOUNT YOU WANTED TO DEPOSIT");
						double bal=sc.nextDouble();
						if(bal>500)
						{
							int accNo1=(int)(Math. random() * 1364381123 + 1364381123);
							long accNo=(long)accNo1;
							Account acc=new Account(bal, accNo1,LocalDate.now());
							bankService.addAccDetails(accNo1, acc);
							System.out.println("ACCOUNT IS SUCESSFULLY CREATED");
							System.out.println("ACCOUNTno:"+accNo1+ "   "+"DATE:"+LocalDate.now());
							
							Customer c=new Customer(cusName,  phoneNo, age1, accNo);
							bankService.addcustDetails(accNo1, c);
							System.out.println("CUSTOMER DETAILS IS SUCESSFULLY ADDED ");
						}
						else
						{
							System.out.println("BALANCE IS BELOW EXPECTED");
						}
					
						
						
						
						
					}
					else
					{
						throw new BankException(age1);
					}
				}catch(BankException e)
				{
					e.getStackTrace();
				}
			}
			else
			{
				throw new BankException(Long.parseLong(phoneNo));
			}
		}
		catch(BankException e)
		{
			e.getStackTrace();
		}
	}
	else
	{
	 throw new BankException(cusName);
	}}
	catch(BankException e)
	{
		e.getStackTrace();
	}
	
	
}


public static void showBalance()
{
	System.out.println("ENTER ACCOUNT NUMBER TO GET BALANCE");
	long accNo=sc.nextLong();
	String accNo1=String.valueOf(accNo);
	try {
	if(bankService.validateAccNO(accNo1)==true)
	{
		HashMap<Long, Account> map=bankService.fetchAccount();
		try {
		if(map.containsKey(accNo))
		{
		
     Account account=bankService.showBalance(accNo);
	double balance=account.getBalance();
	System.out.println("BALANCE IN THE ACCOUNT:"+ balance);
	
	}
		else
		{
			throw new BankException(accNo);
		}}catch(BankException e)
		{
			e.getStackTrace();
		}
	}
		
	else
	{
		throw new BankException(accNo);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
}

public static void toDeposit()
{
	System.out.println("ENTER ACCOUNT NO");
	long accNo=sc.nextLong();
	String accNo1=String.valueOf(accNo);

	if(bankService.validateAccNO(accNo1)==true)
		
	{
		HashMap<Long, Account> map=bankService.fetchAccount();
		try {
		if(map.containsKey(accNo))
		{
		System.out.println("ENTER AMOUNT TO BE DEPOSITED");
		double amount=sc.nextDouble();
	Account acc=	bankService.deposit(accNo, amount);
		double balance1=acc.getBalance();
		double balance=balance1+amount;
		
		Account acc1=new Account(balance, accNo, LocalDate.now());
		System.out.println("AMOUNT SUUCESSFULL DEPOSITED:"+acc1);
		
	}else
	{
		throw new BankException(accNo);
	}}catch(BankException e)
	{
		e.getStackTrace();
	}
	}
	else
	{
		System.out.println("ENTER THE VALID ACCOUNT NO");
	}
	}
		
	
	
	

public static void toWithDraw() 
{
	System.out.println("ENTER ACCOUNT NO");
	long accNo=sc.nextLong();
	String accNo1=String.valueOf(accNo);
	try {
	if(bankService.validateAccNO(accNo1)==true)
		
	{
		HashMap<Long, Account> map=bankService.fetchAccount();
		try {
		if(map.containsKey(accNo))
		{
		System.out.println("ENTER AMOUNT TO BE WITHDRAW");
		double amount=sc.nextDouble();
		Account acc=bankService.withDraw(accNo, amount);
		double bal=acc.getBalance();
		if(amount<(bal-500))
		{
			double balance=bal-amount;
			Account acc1=new Account(balance, accNo, LocalDate.now());
			System.out.println("AMOUNT SUCCESEFULL WITHDRAWN ");
			System.out.println("ACCOUNT BALANCE:"+balance+"  "+ "Date"+LocalDate.now());
			
		}
	}
		else
		{
			throw new BankException(accNo);
		}}catch(BankException e)
		{
			e.getStackTrace();
		}
	}
	else
	{
		throw new BankException(accNo);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
}
	
public static void toFundTransfer()
{
	System.out.println("ENTER THE SENDER ACCOUNT NUMBER");
	long accNo1=sc.nextLong();
	System.out.println("ENTER THE RECIEVER ACCOUNT NUMBER");
	long accNo2= sc.nextLong();
	String accNo3=String.valueOf(accNo1);
	String accNo4=String.valueOf(accNo2);
	try {
	if((bankService.validateAccNO(accNo3)==true)&&(bankService.validateAccNO(accNo4)==true))
	{
		
		HashMap<Long, Account> map=bankService.fetchAccount();
		try {
		if(map.containsKey(accNo1)&&map.containsKey(accNo2))
		{
		System.out.println("ENTER AMOUNT TO BE TRANSFER");
		double amount=sc.nextDouble();
		Account acc=bankService.fundTransfer(accNo1);
		Account acc1=bankService.fundTransfer(accNo2);
		double bal1=acc.getBalance();
		double bal2=acc.getBalance();
		if(amount<(bal1-500))
		{
			
		
			double balance2=bal2+amount;
			double balance1=bal1-amount;
		Account account1=new Account(balance1,accNo1,LocalDate.now());
			Account account2=new Account(balance2, accNo2,LocalDate.now());
			System.out.println("AMOUNT IS TRANSFERED SUCCESFULLY");
			System.out.println("AMOUNT BALANCE IN SENDER:"+balance1+"  "+"Date"+LocalDate.now());
			System.out.println("AMOUNT BALANCE IN RECIVER:"+balance2+"  "+"Date"+LocalDate.now());
		}
	}else
	{
		throw new BankException(accNo1);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
	}
	else
	{
		throw new BankException(accNo1);
	}
}catch(BankException e)
	{
	e.getStackTrace();
	}
		
	
}

}
