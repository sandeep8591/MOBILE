package com.cg.bank.DAO;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface BankDAO {
	public long addcustDetails(long accno,Customer cus );
	public long addAccDetails(long accno,Account acc);
	public Account showBalance(Long accNo);
	public Account deposit(Long accNo,double bal);
	public Account withDraw(Long accNo,double bal);
	public Account fundTransfer(Long accNo);
	public void printTransactions();
	public  HashMap<Long,Account> fetchAccount();
}
