package com.cg.bank.DAO;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;

public class BankDAOImpl implements BankDAO {

	@Override
	public long addcustDetails(long accno,Customer cus ) {
	CollectionUtil.addCustmrDetails(accno, cus);
	return cus.getaccNO();
	}
	@Override
	public long addAccDetails(long accno,Account acc) {
		CollectionUtil.addAccDetails(accno, acc);
		return acc.getAccno();
		}

	@Override
	public Account showBalance(Long accNo) {
	Account account=	CollectionUtil.showBalance(accNo);
	return account;
		
	}

	@Override
	public Account deposit(Long accNo,double bal) {
		
	Account a=	CollectionUtil.deposit(accNo, bal);
		return a;
	}

	@Override
	public Account withDraw(Long accNo,double bal) {
	Account a=CollectionUtil.withDraw(accNo, bal);
	return a;
		
	}

	@Override
	public Account fundTransfer(Long accNo) {
Account account=	CollectionUtil.fundTransferDetails(accNo);
return account;
		
	}

	@Override
	public void printTransactions() {
	
		
	}
	@Override
	public  HashMap<Long,Account> fetchAccount()
	{
		HashMap<Long,Account> map=	CollectionUtil.fetchAccount();
		return map;
	}

}
