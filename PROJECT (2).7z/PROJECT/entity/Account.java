package com.cg.bank.entity;

import java.time.LocalDate;

public class Account {
private double balance;
private long accno;
private LocalDate date;


public Account(double balance,long accno, LocalDate date) {
	super();
	this.balance = balance;
	this.accno = accno;
	this.date = date;
}
@Override
public String toString() {
	return "Account [balance=" + balance + ", accno=" + accno + ", date=" + date + "]";
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public long getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}
public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}

}
