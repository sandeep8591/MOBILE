package com.cg.bank.entity;

import java.time.LocalDate;

public class Customer {

	private String cusName;
	private String cusNo;
	private int age;
	private long accNo;
	
	
	
	public Customer(String cusName, String cusNo, int age,long accNO) {
		super();
		this.cusName = cusName;
		this.cusNo = cusNo;
		this.age = age;
		this.accNo=accNo;
	}
	
	@Override
	public String toString() {
		return "Customer [cusName=" + cusName + ", cusNo=" + cusNo + ", age=" + age + ",accNO="+accNo+"]";
	}

	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusNo() {
		return cusNo;
	}
	public void setCusNo(String cusNo) {
		this.cusNo = cusNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setaccNo(long accNO)
	{
		this.accNo=accNo;
	}
	public long getaccNO()
	{
		return accNo;
		
	}
}
