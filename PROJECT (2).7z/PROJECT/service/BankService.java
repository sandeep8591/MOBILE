package com.cg.bank.service;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface BankService {
	public long addcustDetails(long accno,Customer cus );
	public long addAccDetails(long accno,Account acc );
	public Account showBalance(Long accNo);
public Account deposit(Long accNo,double bal);
public Account withDraw(Long accNo,double bal) ;
public Account fundTransfer(Long accNo);
public void printTransactions();
public boolean validateName(String s);
public boolean validateAge(String h);
public boolean validateCellNo(String sl);
public boolean validateAccNO(String sl);
public  HashMap<Long,Account> fetchAccount();
}
