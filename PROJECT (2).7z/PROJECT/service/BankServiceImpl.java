package com.cg.bank.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.DAO.BankDAO;
import com.cg.bank.DAO.BankDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;


public class BankServiceImpl implements BankService{
BankDAO bankdao=new BankDAOImpl();

	@Override
	public long addcustDetails(long accno,Customer cus ) {
		
		bankdao.addcustDetails(accno,cus);
		return cus.getaccNO();
	}

	@Override
	public long addAccDetails(long accno,Account acc ) {
		
		bankdao.addAccDetails(accno,acc);
		return acc.getAccno();
	}

	@Override
	public Account showBalance(Long accNo) {
		Account account=bankdao.showBalance(accNo);
		return account;
	}

	@Override
	public Account deposit(Long accNo,double bal) {
	Account account=	bankdao.deposit(accNo, bal);
	return account;
	}

	@Override
	public Account withDraw(Long accNo,double bal) {
		
	Account account=	bankdao.withDraw(accNo,bal);
		return account;
	}

	@Override
	public Account fundTransfer(Long accNo) {
		Account account=bankdao.fundTransfer(accNo);
		return account;
	}

	@Override
	public void printTransactions() {
	
		bankdao.printTransactions();
	}

	public boolean validateName(String s)
	{
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{3,9}");
		Matcher m=p.matcher(s)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
	public boolean validateAge(String h)
	{
		Pattern p=Pattern.compile("[1-9]{1}[1-9]{1}");
		Matcher m=p.matcher(h)	;
		if(m.matches())
		{
			return true;
		}
		return false;
	}
	public boolean validateCellNo(String sl)
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(sl)	;
		if(m.matches())
		{
			return true;
		}
		return false;

}
	public boolean validateAccNO(String sl)
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(sl)	;
		if(m.matches())
		{
			return true;
		}
		return false;
}
	@Override
	public  HashMap<Long,Account> fetchAccount()
	{
		HashMap<Long,Account> map=bankdao	.fetchAccount();
		return map;
	}
}
