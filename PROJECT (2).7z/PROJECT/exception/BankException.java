package com.cg.bank.exception;

public class BankException extends Exception{

	public BankException(String name) {
	
		System.out.println("INVALID NAME");
	}
	public BankException(Long phoneNO) {
		
		System.out.println("INVALID phoneNo");
	}
	public BankException(int age)
	{
		System.out.println("MINIMUM AGE IS REQUIRED TO OPEN ACCOUNT");
	}
public BankException(long phoneNO) {
		
		System.out.println("INVALID ACCOUNTNUMBER");
	}

}
